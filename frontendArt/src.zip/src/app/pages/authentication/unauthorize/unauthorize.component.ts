import { Component } from '@angular/core';

@Component({
  selector: 'app-unauthorize',
  standalone: true,
  imports: [],
  templateUrl: './unauthorize.component.html',
  styleUrl: './unauthorize.component.css'
})
export class UnauthorizeComponent {

}
