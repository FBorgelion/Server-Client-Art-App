﻿using BL.Models;

namespace BL.Services.Interfaces
{
    public interface IAdminService
    {

        public void Add(AdminDTO admin);

    }


}
