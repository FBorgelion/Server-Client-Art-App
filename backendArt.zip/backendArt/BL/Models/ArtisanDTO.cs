﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL.Models
{
    public class ArtisanDTO
    {

        public int ArtisanId { get; set; }
        public string ProfileDescription { get; set; }

    }
}
