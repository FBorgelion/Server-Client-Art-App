﻿using Domain;

namespace DAL.Repositories.Interfaces
{
    public interface IAdminRepo
    {
        public void Add(Admin admin);
    }

}
